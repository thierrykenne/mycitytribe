<?php

// CityUserBundle:destination:show.html.twig
return array (
);
