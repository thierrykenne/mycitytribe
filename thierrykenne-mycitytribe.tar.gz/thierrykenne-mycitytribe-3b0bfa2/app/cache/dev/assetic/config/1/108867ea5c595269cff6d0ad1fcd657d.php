<?php

// FOSCommentBundle:Thread:new.html.twig
return array (
  '35a8e64' => 
  array (
    0 => 
    array (
      0 => '@FOSCommentBundle/Resources/assets/js/comments.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/35a8e64.js',
      'name' => '35a8e64',
      'debug' => NULL,
      'combine' => NULL,
    ),
  ),
);
