<?php

// FrameworkBundle:Form:percent_widget.html.php
return array (
);
