<?php

// IsdevTwitterBootstrapBundle::base.html.twig
return array (
  'c0bc382' => 
  array (
    0 => 
    array (
      0 => '@IsdevTwitterBootstrapBundle/Resources/public/bootstrap/css/bootstrap.css',
      1 => '@IsdevTwitterBootstrapBundle/Resources/public/bootstrap/css/bootstrap-responsive.css',
      2 => '@IsdevTwitterBootstrapBundle/Resources/public/css/custom.css',
    ),
    1 => 
    array (
      0 => '?cssembed',
      1 => '?yui_css',
    ),
    2 => 
    array (
      'output' => '_controller/css/c0bc382.css',
      'name' => 'c0bc382',
      'debug' => NULL,
      'combine' => NULL,
    ),
  ),
  '4d23fcb' => 
  array (
    0 => 
    array (
      0 => 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js',
      1 => '@IsdevTwitterBootstrapBundle/Resources/public/bootstrap/js/bootstrap.js',
    ),
    1 => 
    array (
      0 => '?yui_js',
    ),
    2 => 
    array (
      'output' => '_controller/js/4d23fcb.js',
      'name' => '4d23fcb',
      'debug' => NULL,
      'combine' => NULL,
    ),
  ),
);
