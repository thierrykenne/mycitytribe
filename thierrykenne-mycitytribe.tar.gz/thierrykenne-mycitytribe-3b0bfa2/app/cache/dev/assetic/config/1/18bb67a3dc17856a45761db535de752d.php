<?php

// CitytribeBundle:Article:index.html.twig
return array (
);
