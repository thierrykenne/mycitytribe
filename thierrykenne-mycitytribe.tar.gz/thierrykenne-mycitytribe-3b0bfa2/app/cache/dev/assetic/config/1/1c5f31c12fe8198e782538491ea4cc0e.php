<?php

// CityGeoBundle:Destination:new.html.twig
return array (
);
