<?php

// FOSFacebookBundle::initialize.html.php
return array (
);
