<?php

// FrameworkBundle:Form:form_label.html.php
return array (
);
