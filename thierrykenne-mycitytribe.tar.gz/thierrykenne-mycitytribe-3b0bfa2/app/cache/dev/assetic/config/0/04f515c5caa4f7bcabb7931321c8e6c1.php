<?php

// CityBlogBundle:Article:new.html.twig
return array (
);
