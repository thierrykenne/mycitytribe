<?php

// FrameworkBundle:Form:money_widget.html.php
return array (
);
